import React, { useState, useEffect } from "react";

function ProductList({ addToCart }) {
const [products, setProducts] = useState([]);

useEffect(() => {
fetch("http://localhost:5000/api/products")
.then((res) => res.json())
.then((data) => setProducts(data))
.catch((err) => console.error("Error fetching products:", err));
}, []);

return (
<div style={{ textAlign: "center" }}>
<h2>Products</h2>
<div
style={{
display: "flex",
flexWrap: "wrap",
justifyContent: "center",
gap: "20px",
marginTop: "20px",
}}
>
{products.map((p) => (
<div
key={p.id}
style={{
border: "1px solid #ddd",
borderRadius: "10px",
padding: "15px",
width: "180px",
backgroundColor: "white",
boxShadow: "0px 2px 6px rgba(0,0,0,0.1)",
textAlign: "center",
}}
>
<img
src={p.image}
alt={p.name}
style={{
width: "100%",
height: "150px",
borderRadius: "8px",
objectFit: "cover",
}}
/>
<h4>{p.name}</h4>
<p>₹{p.price}</p>
<button
onClick={() => addToCart(p)}
style={{
backgroundColor: "#007bff",
color: "white",
border: "none",
borderRadius: "5px",
padding: "8px 12px",
cursor: "pointer",
}}
>
Add to Cart
</button>
</div>
))}
</div>
</div>
);
}

export default ProductList;
