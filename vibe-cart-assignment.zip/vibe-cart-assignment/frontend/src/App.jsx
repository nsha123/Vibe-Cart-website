import React, { useState } from "react";
import ProductList from "./ProductList";
import Cart from "./Cart";
import Checkout from "./Checkout";

function App() {
const [cart, setCart] = useState([]);

const addToCart = (product) => {
const existing = cart.find((item) => item.id === product.id);
if (existing) {
setCart(
cart.map((item) =>
item.id === product.id ? { ...item, qty: item.qty + 1 } : item
)
);
} else {
setCart([...cart, { ...product, qty: 1 }]);
}
};

const removeFromCart = (id) => {
setCart(cart.filter((item) => item.id !== id));
};

return (
<div>
<h1 style={{ textAlign: "center" }}>🛍️ Vibe Commerce</h1>
<ProductList addToCart={addToCart} />
<Cart cart={cart} removeFromCart={removeFromCart} />
<Checkout cart={cart} />
</div>
);
}

export default App;
