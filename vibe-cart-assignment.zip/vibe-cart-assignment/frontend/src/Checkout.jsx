import React, { useState } from "react";

function Checkout({ cart }) {
const [name, setName] = useState("");
const [email, setEmail] = useState("");
const [receipt, setReceipt] = useState(null);

const handleCheckout = async () => {
const response = await fetch("http://localhost:5000/api/checkout", {
method: "POST",
headers: { "Content-Type": "application/json" },
body: JSON.stringify({ cartItems: cart }),
});
const data = await response.json();
setReceipt(data);
};

return (
<div style={{ textAlign: "center", marginTop: "30px" }}>
<h2>Checkout</h2>
<input
placeholder="Your Name"
value={name}
onChange={(e) => setName(e.target.value)}
/>
<input
placeholder="Your Email"
value={email}
onChange={(e) => setEmail(e.target.value)}
/>
<button onClick={handleCheckout}>Submit</button>

{receipt && (
<div style={{ marginTop: "20px" }}>
<h3>Receipt</h3>
<p>Total: ₹{receipt.total}</p>
<p>Timestamp: {receipt.timestamp}</p>
</div>
)}
</div>
);
}

export default Checkout;