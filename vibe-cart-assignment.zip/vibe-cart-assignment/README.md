# Vibe-Cart-website
Vibe Commerce is a full-stack mock e-commerce shopping cart application built using the MERN-style stack (React + Node + Express + MongoDB).  It allows users to browse products, add or remove items from their cart, view totals, and perform a mock checkout — simulating a simple e-commerce workflow.
